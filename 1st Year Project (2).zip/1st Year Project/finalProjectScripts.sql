use dmaj0918_1074261;

/*DROP ALL TABLES*/

DECLARE @Sql NVARCHAR(500) DECLARE @Cursor CURSOR

SET @Cursor = CURSOR FAST_FORWARD FOR
SELECT DISTINCT sql = 'ALTER TABLE [' + tc2.TABLE_SCHEMA + '].[' +  tc2.TABLE_NAME + '] DROP [' + rc1.CONSTRAINT_NAME + '];'
FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS rc1
LEFT JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc2 ON tc2.CONSTRAINT_NAME =rc1.CONSTRAINT_NAME

OPEN @Cursor FETCH NEXT FROM @Cursor INTO @Sql

WHILE (@@FETCH_STATUS = 0)
BEGIN
Exec sp_executesql @Sql
FETCH NEXT FROM @Cursor INTO @Sql
END

CLOSE @Cursor DEALLOCATE @Cursor
GO

EXEC sp_MSforeachtable 'DROP TABLE ?'
GO


/*IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'kip')
    CREATE DATABASE kip

GO

USE kip;

GO*/

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='users' and xtype='U')
    CREATE TABLE users (
		id INT PRIMARY KEY IDENTITY(1,1) not null,
        username int not null unique,
		name varchar(75) not null,
		password varchar(400) not null,
		typeOfUser int not null,
    )
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='product' and xtype='U')
	CREATE TABLE product (
		id INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
		name VARCHAR(100) NOT NULL UNIQUE,
		price FLOAT NOT NULL,
		typeOfMeat VARCHAR(50) NOT NULL,
		minStock INT NOT NULL, 
		nameOfSupplier VARCHAR(50) NOT NULL,

	)
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='invoice' and xtype='U')
	CREATE TABLE invoice (
		id int PRIMARY KEY IDENTITY(1,1) NOT NULL,
		saleId INT NOT NULL,
		invoiceNo INT NOT NULL,
		amount INT NOT NULL
	)

GO


IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='customer' and xtype='U')
	CREATE TABLE customer(
		id int PRIMARY KEY IDENTITY(1,1) NOT NULL,
		name VARCHAR(100) NOT NULL,
		street VARCHAR(150) NOT NULL,
		numberOnStreet VARCHAR(15) NOT NULL,
		city VARCHAR(30) NOT NULL,
		phoneno VARCHAR(15) NOT NULL,
	)

GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='sale' and xtype='U')
	CREATE TABLE sale (
		id INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
		saleId INT NOT NULL,
		customerId int FOREIGN KEY REFERENCES customer(id),
		date DATE NOT NULL,
		userId int FOREIGN KEY REFERENCES users(id),
		productId int NOT NULL,
		weight FLOAT NOT NULL,
		price FLOAT NOT NULL
	)

GO


IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='store' and xtype='U')
	CREATE TABLE store (
		id INT PRIMARY KEY IDENTITY(1,1) NOT NULL, 
		storeName VARCHAR(50), 
		address VARCHAR(70), 
	)

GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='delivery' and xtype='U')
	CREATE TABLE delivery (
		id INT PRIMARY KEY IDENTITY(1,1) NOT NULL, 
		deliveryId INT NOT NULL,
		storeId INT FOREIGN KEY REFERENCES store(id),
		deliveryDate DATE NOT NULL,
		weight FLOAT not null,
		productId int NOT NULL,
		userId int FOREIGN KEY REFERENCES users(id),
		
	)

GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='warehouse' and xtype='U')
	CREATE TABLE warehouse (
		serialNumber INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
		stock FLOAT NOT NULL,
		expireDate DATE NOT NULL,
		dateOfProduce DATE NOT NULL,
		productId INT FOREIGN KEY REFERENCES product(id),
		productName VARCHAR(100) NOT NULL
		
	)

GO



insert into store(storeName, address) values ('store1','address1');
insert into store(storeName, address) values ('store2','address2');
insert into store(storeName, address) values ('store3','address3');
insert into store(storeName, address) values ('store4','address4');
insert into store(storeName, address) values ('store5','address5');
insert into store(storeName, address) values ('store6','address6');


insert into users(username,name, password, typeOfUser) values (001,'Yordan','$2a$12$9GrLfe8kUqSl2yrvN3IBPO9NTx6je90B1OLPBISOnRXlpmeMN411q', 1);
insert into users(username,name, password, typeOfUser) values (002,'Lyudmil','$2a$12$9GrLfe8kUqSl2yrvN3IBPO9NTx6je90B1OLPBISOnRXlpmeMN411q', 1);
insert into users(username,name, password, typeOfUser) values (003,'Jan','$2a$12$9GrLfe8kUqSl2yrvN3IBPO9NTx6je90B1OLPBISOnRXlpmeMN411q', 2);
insert into users(username,name, password, typeOfUser) values (004,'Henrique','$2a$12$9GrLfe8kUqSl2yrvN3IBPO9NTx6je90B1OLPBISOnRXlpmeMN411q', 2);
insert into users(username,name, password, typeOfUser) values (005,'Valentin','$2a$12$9GrLfe8kUqSl2yrvN3IBPO9NTx6je90B1OLPBISOnRXlpmeMN411q', 2);


insert into product(price, typeOfMeat, minStock, nameOfSupplier, name) values (30.00,'Pork', 50.00,'BulgarianMafia','Sausage');
insert into product(price, typeOfMeat, minStock, nameOfSupplier, name) values (20.00,'Chicken', 60.00,'MafiaOfVarna','Chilli Sausage');
insert into product(price, typeOfMeat, minStock, nameOfSupplier, name) values (20.00,'Chicken', 60.00,'LotOfBalls','Meatball');
insert into product(price, typeOfMeat, minStock, nameOfSupplier, name) values (40.00,'Beef', 30.00,'LotOfMeat','Steak');
insert into product(price, typeOfMeat, minStock, nameOfSupplier, name) values (40.00,'Beef', 30.00,'WeHaveMeat','Ground Meat');
insert into product(price, typeOfMeat, minStock, nameOfSupplier, name) values (30.00,'Pork', 70.00,'GiveMeMeat','Pork Meatball');
insert into product(price, typeOfMeat, minStock, nameOfSupplier, name) values (30.00,'Lamb', 70.00,'BeatMyMeat','Lamb Sausage');

insert into customer(name, street, numberOnStreet, city, phoneno) values ('Rumen Radev','ul. Vasil Levski','10','Varna','+35900123456');
insert into customer(name, street, numberOnStreet, city, phoneno) values ('Boyko Borissov','ul. Tsar Osvoboditel','13','Varna','+35900567488');
insert into customer(name, street, numberOnStreet, city, phoneno) values ('Hristo Stoichkov','ul. Doyran','22','Varna','+359654098');
insert into customer(name, street, numberOnStreet, city, phoneno) values ('Blagoy Makendzhiev','ul. Makedonia','13','Varna','+359999234651');
insert into customer(name, street, numberOnStreet, city, phoneno) values ('Nikolay Dimitrov','ul. Drin','19','Varna','+3595323963');
insert into customer(name, street, numberOnStreet, city, phoneno) values ('Svetoslav Kovachev','ul. Baba Tonka','2','Varna','+359123456789');
insert into customer(name, street, numberOnStreet, city, phoneno) values ('Martin Raynov','ul. Nikola Kanev','9','Varna','+359765321009');
